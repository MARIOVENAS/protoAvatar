function swap(){
	for (var i=0;i<es.length;i++){
		$("[id=t"+i+"]").each(function(){
			if(this.tagName.toUpperCase()=="INPUT")
				this.value = es[i];
			else
				this.innerHTML = es[i];});
	}
}